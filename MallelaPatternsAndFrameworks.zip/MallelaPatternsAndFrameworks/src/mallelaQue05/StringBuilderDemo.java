/**
 * 
 */
package mallelaQue05;

/**
 * @author S546832
 *
 */
public class StringBuilderDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder("Hello");
		str.append(" World!");
		System.out.println(str);
	}

}
