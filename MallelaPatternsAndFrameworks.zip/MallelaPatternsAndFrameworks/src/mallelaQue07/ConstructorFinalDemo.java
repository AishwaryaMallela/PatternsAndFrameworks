/**
 * 
 */
package mallelaQue07;

/**
 * @author S546832
 *
 */
public class ConstructorFinalDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorFinalDemo obj1 = new ConstructorFinalDemo();
	}

	final ConstructorFinalDemo(){
        System.out.println("Final Constructor");
    }
}
