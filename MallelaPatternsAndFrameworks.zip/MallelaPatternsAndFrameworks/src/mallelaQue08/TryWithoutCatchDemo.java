/**
 * 
 */
package mallelaQue08;

/**
 * @author S546832
 *
 */
public class TryWithoutCatchDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
	         System.out.println("Try Block");
	      } finally {
	         System.out.println("Finally Block");
	      }
	}

}
