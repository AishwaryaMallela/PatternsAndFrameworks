/**
 * 
 */
package mallelaQue12;

/**
 * @author S546832
 *
 */
public class FinalDemo {

	final int age = 18;  
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub      
		FinalDemo fd = new FinalDemo();   
	    fd.display(); 
	}
	
	void display() {    
	    age = 55;  
	    }  

}
