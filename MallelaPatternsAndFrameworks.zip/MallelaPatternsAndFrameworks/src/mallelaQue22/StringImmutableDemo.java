/**
 * 
 */
package mallelaQue22;

/**
 * @author S546832
 *
 */
public class StringImmutableDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "java";
        s1.concat(" rules");
        System.out.println("s1 refers to " + s1);
	}

}
