/**
 * 
 */
package mallelaQue25;

import java.util.ArrayList;
import java.util.List;

/**
 * @author S546832
 *
 */
public class Features {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> l = new ArrayList<Integer>();
        for(int i=0;i<=2;i++) { 
        	l.add(i);
        }
        l.forEach(i -> System.out.println(i));
	}

	
}
